/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermarket.management.system.project;

import java.io.IOException;

/**
 *
 * @author Sama
 */
public class SupermarketManagementSystemProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        // TODO code application logic here
        //Login lo=new Login();
        //Categories c = new Categories();
        //Products p=new Products();
        splash s=new splash();
        //UpdateAdmin a=new UpdateAdmin();
        //MainPage m = new MainPage();
        //Seller se = new Seller();
        //Selling sel=new Selling();
    }
    
}
